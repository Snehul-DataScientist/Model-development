# -*- coding: utf-8 -*-
"""
Created on Wed Apr 12 11:17:27 2017

@author: snehalpatil
"""
import pandas as pd
import numpy as np
import pdb 
import os
from iteration_utilities import flatten
##########OUtput processing2##############################

def final_x2y2_Firstname(final_result):
    f_co_ord=[]
    for i in range(len(final_result)):
        w = final_result['GivenName_xy1'][i]
        w1 = final_result['GivenName_xy2'][i]
      
        if (len(w) >= 1) and (len(w1) >= 1):
            t=w[0].split(',')
            t1=w1[0].split(',')
            if (len(t) >= 4) and (len(t1) >= 4):
                co_ord = t[0] + ','+ t[1] + ','+ t1[2] + ','+ t1[3]
                #print co_ord
                f_co_ord.append(co_ord)
            else:
                co_ord1 = ""
                f_co_ord.append(co_ord1)
        else:
            co_ord1 = ""
            f_co_ord.append(co_ord1)
    df8 = pd.DataFrame({"GivenName_x1y1x2y2": f_co_ord})
    return df8
#######################Check for last name#######################
def final_x2y2_lastname(final_result):
    f_co_ord=[]
    for i in range(len(final_result)):
        w = final_result['lastName_xy1'][i]
        w1 = final_result['lastName_xy2'][i]
        print w,w1
      
        if (len(w) >= 1) and (len(w1) >= 1):
            t=w[0].split(',')
            t1=w1[0].split(',')
            if (len(t) >= 4) and (len(t1) >= 4):
                co_ord = t[0] + ','+ t[1] + ','+ t1[2] + ','+ t1[3]
                #print co_ord
                f_co_ord.append(co_ord)
            else:
                co_ord1 = ""
                f_co_ord.append(co_ord1)
        else:
            co_ord1 = ""
            f_co_ord.append(co_ord1)
    df11 = pd.DataFrame({"SurName_x1y1x2y2": f_co_ord})
    return df11
    
def final_x2y2_occ(final_result):
    f_co_ord=[]
    for i in range(len(final_result)):
        w = final_result['Occ_xy1'][i]
        w1 = final_result['Occ_xy2'][i]
      
        if (len(w) >= 1) and (len(w1) >= 1):
            t=w[0].split(',')
            t1=w1[0].split(',')
            if (len(t) >= 4) and (len(t1) >= 4):
                co_ord = t[0] + ','+ t[1] + ','+ t1[2] + ','+ t1[3]
                #print co_ord
                f_co_ord.append(co_ord)
            else:
                co_ord1 = ""
                f_co_ord.append(co_ord1)
        else:
            co_ord1 = ""
            f_co_ord.append(co_ord1)
    df12 = pd.DataFrame({"Occupation_x1y1x2y2": f_co_ord})
    return df12
    
def final_x2y2_add(final_result):
    f_co_ord=[]
    for i in range(len(final_result)):
        w = final_result['Add_xy1'][i]
        w1 = final_result['Add_xy2'][i]
      
        if (len(w) >= 1) and (len(w1) >= 1):
            t=w[0].split(',')
            t1=w1[0].split(',')
            if (len(t) >= 4) and (len(t1) >= 4):
                co_ord = t[0] + ','+ t[1] + ','+ t1[2] + ','+ t1[3]
                #print co_ord
                f_co_ord.append(co_ord)
            else:
                co_ord1 = ""
                f_co_ord.append(co_ord1)
        else:
            co_ord1 = ""
            f_co_ord.append(co_ord1)
    df13 = pd.DataFrame({"Address_x1y1x2y2": f_co_ord})
    return df13
    
def prefix(final_result):
    f_co_ord=[]
    for i in range(len(final_result)):
        w = final_result['Prefix_xy1'][i]
        w1 = final_result['Prefix_xy2'][i]
      
        if (len(w) >= 1) and (len(w1) >= 1):
            t=w[0].split(',')
            t1=w1[0].split(',')
            if (len(t) >= 4) and (len(t1) >= 4):
                co_ord = t[0] + ','+ t[1] + ','+ t1[2] + ','+ t1[3]
                #print co_ord
                f_co_ord.append(co_ord)
            else:
                co_ord1 = ""
                f_co_ord.append(co_ord1)
        else:
            co_ord1 = ""
            f_co_ord.append(co_ord1)
    df13 = pd.DataFrame({"Prefix_x1y1x2y2": f_co_ord})
    return df13
    
def suffix(final_result):
    f_co_ord=[]
    for i in range(len(final_result)):
        w = final_result['Suffix_1_xy1'][i]
        w1 = final_result['Suffix_2_xy2'][i]
      
        if (len(w) >= 1) and (len(w1) >= 1):
            t=w[0].split(',')
            t1=w1[0].split(',')
            if (len(t) >= 4) and (len(t1) >= 4):
                co_ord = t[0] + ','+ t[1] + ','+ t1[2] + ','+ t1[3]
                #print co_ord
                f_co_ord.append(co_ord)
            else:
                co_ord1 = ""
                f_co_ord.append(co_ord1)
        else:
            co_ord1 = ""
            f_co_ord.append(co_ord1)
    df13 = pd.DataFrame({"Suffix_x1y1x2y2": f_co_ord})
    return df13
    