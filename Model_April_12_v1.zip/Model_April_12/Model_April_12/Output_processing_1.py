# -*- coding: utf-8 -*-
"""
Created on Wed Apr 12 15:08:15 2017

@author: snehalpatil
"""

import pandas as pd
import numpy as np
import pdb 
import os
from iteration_utilities import flatten



def firs_cord(result1):
    giv=[]
    vav=[]    
    for i in range(len(result1)):
        w=result1['First_name'][i]
        #print type(w)
        if type(w) == dict:
            y = w.keys()
            v= w.values()
            giv.append(y)
            vav.append(v)
        else:
            y1=list(flatten(w))
            y2=""
            giv.append(y1)
            vav.append(y2)
    #print len(giv),len(vav)
    df6 = pd.DataFrame({"First_Name_c": giv, "GivenName_xy1" :vav})
    return df6

def firs1_cord(result1):
    giv=[]
    vav=[]    
    for i in range(len(result1)):
        w=result1['First_name_1'][i]
        if type(w) == dict:
            y = w.keys()
            v= w.values()
            giv.append(y)
            vav.append(v)
        else:
            y1=list(flatten(w))
            y2=""
            giv.append(y1)
            vav.append(y2)
    #print len(giv),len(vav)
    df7 = pd.DataFrame({"First_Name2_c": giv, "GivenName_xy2" :vav})
    return df7

def las1_cord(result1):
    giv=[]
    vav=[]    
    for i in range(len(result1)):
        w=result1['Last_name_1'][i]
        if type(w) == dict:
            y = w.keys()
            v= w.values()
            giv.append(y)
            vav.append(v)
        else:
            y1=list(flatten(w))
            y2=""
            giv.append(y1)
            vav.append(y2)
    #print len(giv),len(vav)
    df8 = pd.DataFrame({"LastName1_c": giv, "lastName_xy1" :vav})
    return df8

def las2_cord(result1):
    giv=[]
    vav=[]    
    for i in range(len(result1)):
        w=result1['Last_name_2'][i]
        if type(w) == dict:
            y = w.keys()
            v= w.values()
            giv.append(y)
            vav.append(v)
        else:
            y1=list(flatten(w))
            y2=""
            giv.append(y1)
            vav.append(y2)
    #print len(giv),len(vav)
    df9 = pd.DataFrame({"LastName2_c": giv, "lastName_xy2" :vav})
    return df9

def Occ1_cord(result1):
    giv=[]
    vav=[]    
    for i in range(len(result1)):
        w=result1['Occupation_1'][i]
        if type(w) == dict:
            y = w.keys()
            v= w.values()
            giv.append(y)
            vav.append(v)
        else:
            y1=list(flatten(w))
            y2=""
            giv.append(y1)
            vav.append(y2)
    #print len(giv),len(vav)
    df10 = pd.DataFrame({"OccName1_c": giv, "Occ_xy1" :vav})
    return df10
    
def Occ2_cord(result1):
    giv=[]
    vav=[]    
    for i in range(len(result1)):
        w=result1['Occupation_2'][i]
        if type(w) == dict:
            y = w.keys()
            v= w.values()
            giv.append(y)
            vav.append(v)
        else:
            y1=list(flatten(w))
            y2=""
            giv.append(y1)
            vav.append(y2)
    #print len(giv),len(vav)
    df11 = pd.DataFrame({"OccName2_c": giv, "Occ_xy2" :vav})
    return df11

def add1_cord(result1):
    giv=[]
    vav=[]    
    for i in range(len(result1)):
        w=result1['add_1'][i]
        if type(w) == dict:
            y = w.keys()
            v= w.values()
            giv.append(y)
            vav.append(v)
        else:
            y1=list(flatten(w))
            y2=""
            giv.append(y1)
            vav.append(y2)
    #print len(giv),len(vav)
    df12 = pd.DataFrame({"AddName1_c": giv, "Add_xy1" :vav})
    return df12    
 
def add2_cord(result1):
    giv=[]
    vav=[]    
    for i in range(len(result1)):
        w=result1['add_1'][i]
        if type(w) == dict:
            y = w.keys()
            v= w.values()
            giv.append(y)
            vav.append(v)
        else:
            y1=list(flatten(w))
            y2=""
            giv.append(y1)
            vav.append(y2)
    #print len(giv),len(vav)
    df13 = pd.DataFrame({"AddName2_c": giv, "Add_xy2" :vav})
    return df13   