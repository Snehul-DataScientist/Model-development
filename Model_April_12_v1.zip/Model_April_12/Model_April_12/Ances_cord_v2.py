# -*- coding: utf-8 -*-
"""
Created on Mon Apr 10 16:56:35 2017

@author: snehalpatil
"""

import pandas as pd
import numpy as np
import pdb 
import os
import Output_processing_1
import Output_processing2
from iteration_utilities import flatten
from Output_processing_1 import *
from Output_processing2 import *
   
def x2y2calc(df): ####Calculating x2 and y2 co-ordinates
       df['x2']=df['x1'] + df['width1']
       df['y2']=df['y1'] - df['Height1']
       return df
#############Matching the words and gettiing the co=ordinates from the dataframe#######################
def word_coord(word):
    tdf=df[df['txt1'].str.contains(word, regex=False)]
    if tdf.empty:    
        coord=rowname=""
    else:
        tdf=tdf.iloc[0,3:7]
        coord=str(tdf[0])+","+str(tdf[1])+","+str(tdf[2])+","+str(tdf[3])
        rowname=tdf.name     
    return (coord, rowname)
    
def worddict(wordlist): 
    wordlist=wordlist.split()    

    worddictlist=[]

    for word in wordlist:        
        wordcoord={word:word_coord(word)[0]}
        worddictlist.append(wordcoord)
        idx=word_coord(word)[1]
        if idx !="":
            df.drop(word_coord(word)[1], inplace=True)
    return (worddictlist)
    
def stringlist(rowstringlist):
    stringdictlist=[]
    for string in rowstringlist:
        strdict=worddict(string)
        stringdictlist.append(strdict)
    return(stringdictlist) 
#########################################################################################    
################For getting the last name f ########################################
    #################################################################################
######Extraction of respective words and co-ordinates from the dataframe###################
#########################################################################################
def last_name(df4):    
    g=[]
    y=[]
    file_name=[]
    for i in range(len(df4)):
        leng =len(df4[i][3])
        if leng > 1:
            j = leng - 1
            fir_nam = df4[i][3][0] 
            file_n = df4[0][0] 
            las_nam = df4[i][3][j] 
            g.append(fir_nam)
            y.append(las_nam)
            file_name.append(file_n)
            
            
        else:
            l = df4[i][3]
            file_n = df4[0][0] 
            las = "NA"
            g.append(l)
            y.append(las)
            file_name.append(file_n)
       
    df_v = pd.DataFrame({"FileName":file_name, "Last_name_1": g, "Last_name_2" :y})
    return df_v     
###################For getting the firstname######################  
    
def first_name(df4):    
    g=[]
    y=[]
    file_name=[]
    for i in range(len(df4)):
        leng =len(df4[i][2])
        if leng > 1:
            j = leng - 1
            fir_nam = df4[i][2][0] 
            las_nam = df4[i][2][j] 
            file_n = df4[0][0] 
            g.append(fir_nam)
            y.append(las_nam)
            file_name.append(file_n)
            
            
        else:
            l = df4[i][2]
            file_n = df4[0][0] 
            las = "NA"
            g.append(l)
            y.append(las)
            file_name.append(file_n)
       
    df_va = pd.DataFrame({"First_name": g, "First_name_1" :y})
    return df_va     
##############################################################33
######Extracting occupation as well as address#############
def occ(df4):
    g=[]
    y=[]
    file_name=[]
    df_vali=pd.DataFrame() 
    for i in range(len(df4)):
        leng =len(df4[i][6])
        if leng > 1:
            j = leng - 1
            fir_occ = df4[i][6][0] 
            las_occ = df4[i][6][j]
            file_n = df4[0][0] 
            g.append(fir_occ)
            y.append(las_occ)
            file_name.append(file_n)
            
        else:
            l = df4[i][6]
            file_n = df4[0][0]
            las = "NA"
            g.append(l)
            y.append(las)
            file_name.append(file_n)
   
    df_vali = pd.DataFrame({"Occupation_1": g, "Occupation_2" :y})
    return df_vali
######################################################
def add(df4):
    g=[]
    y=[]
    file_name=[]
    df_vali=pd.DataFrame() 
    for i in range(len(df4)):
        leng =len(df4[i][7])
        if leng > 1:
            j = leng - 1
            fir_occ = df4[i][7][0] 
            las_occ = df4[i][7][j]
            file_n = df4[0][0] 
            g.append(fir_occ)
            y.append(las_occ)
            file_name.append(file_n)
            
        else:
            l = df4[i][7]
            file_n = df4[0][0]
            las = "NA"
            g.append(l)
            y.append(las)
            file_name.append(file_n)
   
    df_valid = pd.DataFrame({"add_1": g, "add_2" :y})
    return df_valid
#########################################################
#########################################################################################
if __name__ == '__main__':  
    path = "/home/snehalpatil/Desktop/ANCESTORY/Ram_extracted_output/2017-04-0746928_553244-00002.j2k.00001.single.ecmdoc_formatted.txt_output.csv"  #####csv obtained from json with x,y co-ordinates
    df2 = pd.read_csv(path, dtype={'Filename': object},sep=',',keep_default_na=False)
    path = "/home/snehalpatil/Desktop/ANCESTORY/Ances_Model_april7/output/46928_553244-00002.j2k.00001.csv"  #### csv with extracted names#################
    df = pd.read_csv(path, dtype={'Filename': object},sep=',',keep_default_na=False)
    df=x2y2calc(df)
    df3=pd.DataFrame({'row':df2.as_matrix(columns=None).tolist()})  
    df4=df3['row'].apply(stringlist)  
    df_va=first_name(df4)
    df_v=last_name(df4)
    df_vali=occ(df4)
    df_valid=add(df4)
    frames = [df_va, df_v, df_vali,df_valid,df2]
    result = pd.concat(frames,axis=1)
    result1=result
    A=Output_processing_1.firs_cord(result1)
    B=Output_processing_1.firs1_cord(result1)
    C=Output_processing_1.las1_cord(result1)
    D=Output_processing_1.las2_cord(result1)
    E=Output_processing_1.Occ1_cord(result1)
    F=Output_processing_1.Occ2_cord(result1)
    G=Output_processing_1.add1_cord(result1)
    H=Output_processing_1.add2_cord(result1)
    frames=[A,B,C,D,E,F,G,H,df2]
    f_result = pd.concat(frames,axis=1)
    final_result=f_result[['FileName','Sno','GivenName','GivenName_xy1','GivenName_xy2','SurName','lastName_xy1','lastName_xy2','Prefix','Suffix','Occupation','Occ_xy1','Occ_xy2','Address','Add_xy1','Add_xy2']]
    GivenName_x1y1x2y2=Output_processing2.final_x2y2_Firstname(final_result)
    SurName_x1y1x2y2=Output_processing2.final_x2y2_lastname(final_result)
    Occupation_x1y1x2y2=Output_processing2.final_x2y2_occ(final_result)
    Address_x1y1x2y2=Output_processing2.final_x2y2_add(final_result)
    frames=[GivenName_x1y1x2y2,SurName_x1y1x2y2,Occupation_x1y1x2y2,Address_x1y1x2y2,final_result]
    final_result1 = pd.concat(frames,axis=1)   
    final_result2=final_result1[['FileName','Sno','GivenName','GivenName_x1y1x2y2','SurName','SurName_x1y1x2y2','Prefix','Suffix','Occupation','Occupation_x1y1x2y2','Address','Address_x1y1x2y2']]
    final_result2.to_csv("/home/snehalpatil/Desktop/ANCESTORY/Ances_Model_april7/output/co_ordinate_calc_output/final/final_output_12_april_txt_coord.csv", encoding='utf-8', index=False)
   